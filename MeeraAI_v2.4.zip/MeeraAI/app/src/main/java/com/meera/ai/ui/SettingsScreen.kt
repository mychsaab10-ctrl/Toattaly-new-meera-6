@file:OptIn(ExperimentalMaterial3Api::class)

package com.meera.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.meera.ai.Meera
import com.meera.ai.ai.GeminiException
import com.meera.ai.automation.QuickAccess
import kotlinx.coroutines.launch

@Composable
private fun ModelField(label: String, value: String, options: List<String>, onChange: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value, onChange, Modifier.weight(1f), label = { Text(label) }, singleLine = true,
            trailingIcon = { if (options.isNotEmpty()) TextButton(onClick = { open = true }) { Text("▼") } }
        )
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { o -> DropdownMenuItem(text = { Text(o) }, onClick = { onChange(o); open = false }) }
        }
    }
}

@Composable
fun SettingsScreen() {
    val s = Meera.settings
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    var hasKey by remember { mutableStateOf(Meera.keys.has()) }
    var editing by remember { mutableStateOf(!Meera.keys.has()) }
    var keyInput by remember { mutableStateOf("") }
    var status by remember { mutableStateOf(if (Meera.keys.has()) "Key saved (not tested yet)" else "No key") }
    var statusOk by remember { mutableStateOf<Boolean?>(null) }
    var busy by remember { mutableStateOf(false) }

    var model by remember { mutableStateOf(s.model) }
    var liveModel by remember { mutableStateOf(s.liveModel) }
    var voice by remember { mutableStateOf(s.voice) }
    var temp by remember { mutableStateOf(s.temperature) }
    var pName by remember { mutableStateOf(s.personaName) }
    var pStyle by remember { mutableStateOf(s.personaStyle) }
    var lang by remember { mutableStateOf(s.language) }
    var cc by remember { mutableStateOf(s.countryCode) }
    var theme by remember { mutableStateOf(s.theme) }
    var useLive by remember { mutableStateOf(s.useLive) }
    var autoFb by remember { mutableStateOf(s.autoFallback) }
    var autoSpeak by remember { mutableStateOf(s.autoSpeak) }
    var quick by remember { mutableStateOf(s.quickAccess) }
    var eScan by remember { mutableStateOf(s.eyesScanSec) }
    var eHud by remember { mutableStateOf(s.eyesHud) }
    var eFront by remember { mutableStateOf(s.eyesFront) }
    var eAuto by remember { mutableStateOf(s.eyesAutoCloseMin) }
    var eCont by remember { mutableStateOf(s.eyesContinuous) }
    var eLive by remember { mutableStateOf(s.liveVideo) }
    var aMode by remember { mutableStateOf(s.auraMode) }
    var aStr by remember { mutableStateOf(s.auraStrength.toFloat()) }
    var aAll by remember { mutableStateOf(s.auraAllStates) }
    var aMem by remember { mutableStateOf(s.autoMemory) }
    val auraCtx = LocalContext.current
    var sttLang by remember { mutableStateOf(s.sttLang) }
    var ttsLang by remember { mutableStateOf(s.ttsLang) }
    var models by remember { mutableStateOf(s.modelsCache.split(",").filter { it.isNotBlank() }) }
    var liveModels by remember { mutableStateOf(s.liveCache.split(",").filter { it.isNotBlank() }) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Settings", fontSize = 22.sp, color = MaterialTheme.colorScheme.primary)

        SectionTitle("Gemini API key")
        if (hasKey && !editing) {
            Text("Saved: ${Meera.keys.masked()}", color = MaterialTheme.colorScheme.onSurface)
        } else {
            OutlinedTextField(
                keyInput, { keyInput = it }, Modifier.fillMaxWidth(), label = { Text("API key") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation()
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (editing) {
                Button(enabled = keyInput.isNotBlank(), onClick = {
                    Meera.keys.save(keyInput); keyInput = ""; hasKey = true; editing = false
                    status = "Key saved (not tested yet)"; statusOk = null
                }) { Text("Save") }
            } else {
                OutlinedButton(onClick = { editing = true }) { Text("Edit") }
            }
            OutlinedButton(enabled = hasKey, onClick = {
                Meera.keys.clear(); hasKey = false; editing = true; status = "Key removed"; statusOk = false
            }) { Text("Remove") }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = hasKey && !busy, onClick = {
                busy = true; status = "Testing…"; statusOk = null
                scope.launch {
                    try {
                        val r = Meera.gemini.test(s.model)
                        status = "Connected ✓ (${s.model} replied: ${r.take(20)})"; statusOk = true
                    } catch (e: GeminiException) {
                        status = e.message ?: "Error"; statusOk = false
                    }
                    busy = false
                }
            }) { Text("Test connection") }
            Chip(status, statusOk)
        }
        Text(
            "The key is encrypted with the Android Keystore (AES-256-GCM) and stored only on this phone, never in the source code or logs. " +
                "Never put a key inside the APK. Do not share your key; set a usage limit in Google AI Studio.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        SectionTitle("Models")
        ModelField("Chat model", model, models) { model = it; s.model = it }
        ModelField("Live (voice) model", liveModel, liveModels) { liveModel = it; s.liveModel = it }
        OutlinedButton(enabled = hasKey && !busy, onClick = {
            busy = true; status = "Loading model list…"; statusOk = null
            scope.launch {
                try {
                    val (t, l) = Meera.gemini.listModels()
                    models = t; liveModels = l
                    s.modelsCache = t.joinToString(","); s.liveCache = l.joinToString(",")
                    status = "Found ${t.size} chat and ${l.size} live models"; statusOk = true
                } catch (e: GeminiException) {
                    status = e.message ?: "Error"; statusOk = false
                }
                busy = false
            }
        }) { Text("Refresh list from Google") }
        Text("Model names change often - pick one from the list that your key supports.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("Creativity (temperature): ${"%.1f".format(temp)}")
        Slider(value = temp, onValueChange = { temp = it; s.temperature = it }, valueRange = 0f..2f)

        SectionTitle("Meera's personality")
        OutlinedTextField(pName, { pName = it; s.personaName = it }, Modifier.fillMaxWidth(), label = { Text("Name") }, singleLine = true)
        OutlinedTextField(pStyle, { pStyle = it; s.personaStyle = it }, Modifier.fillMaxWidth(), label = { Text("Personality description") }, minLines = 2)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Roman Urdu", "English").forEach { l ->
                FilterChip(selected = lang == l, onClick = { lang = l; s.language = l }, label = { Text(l) })
            }
        }
        ModelField("Voice (Live)", voice, listOf("Aoede", "Kore", "Leda", "Zephyr", "Puck", "Charon", "Fenrir", "Orus")) { voice = it; s.voice = it }

        SectionTitle("WhatsApp / SMS")
        OutlinedTextField(
            cc, { cc = it.filter { c -> c.isDigit() }.take(4); s.countryCode = cc }, Modifier.fillMaxWidth(),
            label = { Text("Default country code (for example 92, 91, 971)") }, singleLine = true
        )
        Text(
            "Used for numbers without a country code. Contacts are searched only on the phone; names and numbers are not sent to Gemini.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        SectionTitle("Voice call")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(useLive, { useLive = it; s.useLive = it }); Text("  Use Gemini Live (natural voice)")
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(autoFb, { autoFb = it; s.autoFallback = it }); Text("  Auto fallback if Live fails")
        }
        Text("Fallback voice languages (phone recognizer / TTS): ur-PK = Urdu, en-IN / en-US = English. en-IN reads Roman Urdu best.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("ur-PK", "en-IN", "en-US").forEach { l ->
                FilterChip(selected = sttLang == l, onClick = { sttLang = l; s.sttLang = l }, label = { Text("hear $l") })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("ur-PK", "en-IN", "en-US").forEach { l ->
                FilterChip(selected = ttsLang == l, onClick = { ttsLang = l; s.ttsLang = l }, label = { Text("speak $l") })
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(autoSpeak, { autoSpeak = it; s.autoSpeak = it }); Text("  Speak chat replies automatically")
        }

        SectionTitle("Memory")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(aMem, { aMem = it; s.autoMemory = it }); Text("  Auto memory (remember lasting things I say)")
        }
        Text(
            "On: after you speak, Meera quietly saves lasting facts (name, family, plans, likes...) on this phone, like ChatGPT memory. Passwords, OTPs and card/ID numbers are never saved. See and delete everything in the Memory screen.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        SectionTitle("Meera Eyes (camera)")
        Text(
            "The camera runs only on your command: \"Meera open your eyes\" / \"aankhein kholo\" / \"camera on\". " +
                "Close it with \"close your eyes\" / \"aankhein band karo\" / \"camera off\".",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text("HUD scan interval: ${"%.1f".format(eScan)} seconds")
        Slider(
            value = eScan,
            onValueChange = { v -> val r = Math.round(v * 2f) / 2f; eScan = r; s.eyesScanSec = r },
            valueRange = 2f..5f, steps = 5
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(eHud, { eHud = it; s.eyesHud = it }); Text("  HUD boxes (brackets + labels on objects)")
        }
        Text("Default camera", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !eFront, onClick = { eFront = false; s.eyesFront = false }, label = { Text("Back") })
            FilterChip(selected = eFront, onClick = { eFront = true; s.eyesFront = true }, label = { Text("Front") })
        }
        Text("Auto-close (the eyes close by themselves after this many minutes)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(1, 2, 5, 10, 15).forEach { m ->
                FilterChip(selected = eAuto == m, onClick = { eAuto = m; s.eyesAutoCloseMin = m }, label = { Text("$m min") })
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(eCont, { eCont = it; s.eyesContinuous = it }); Text("  Continuous description (Meera keeps talking)")
        }
        Text(
            "Off (default): Meera stays silent and only shows the HUD until you ask something.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text("Live call + camera", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = eLive == "stream", onClick = { eLive = "stream"; s.liveVideo = "stream" }, label = { Text("Stream (1 frame/s)") })
            FilterChip(selected = eLive == "snapshot", onClick = { eLive = "snapshot"; s.liveVideo = "snapshot" }, label = { Text("Snapshot (per question)") })
        }
        Text(
            "Stream: about 1 frame per second goes to the Live model (Google's docs say the Live API accepts video frames). " +
                "If your Live model rejects video, the app switches to Snapshot mode by itself.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            "Privacy: frames go only to Gemini while the eyes are ON. Nothing is saved or recorded.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        SectionTitle("Meera Aura (border while speaking)")
        Text(
            "A glowing border around the screen edges while Meera listens, thinks and speaks. While she speaks it pulses with her voice.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = aMode == "off", onClick = { aMode = "off"; s.auraMode = "off"; Meera.aura.settingsChanged() }, label = { Text("Off") })
            FilterChip(selected = aMode == "app", onClick = { aMode = "app"; s.auraMode = "app"; Meera.aura.settingsChanged() }, label = { Text("App only") })
            FilterChip(selected = aMode == "phone", onClick = {
                aMode = "phone"; s.auraMode = "phone"; Meera.aura.settingsChanged()
            }, label = { Text("Whole phone") })
        }
        if (aMode == "phone" && !Meera.aura.canShowOverPhone()) {
            Text(
                "For \"Whole phone\" turn on ONE of these. Until then the border shows only inside the app.\n" +
                    "1) \"Display over other apps\" (some phones switch it off: \"Feature not available\").\n" +
                    "2) Turn on Meera in Accessibility. That is enough for the border; screen control still needs its own switch inside Meera.",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    auraCtx.startActivity(
                        android.content.Intent(
                            android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            android.net.Uri.parse("package:" + auraCtx.packageName)
                        ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }) { Text("Overlay permission") }
                OutlinedButton(onClick = {
                    auraCtx.startActivity(
                        android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)
                            .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }) { Text("Turn on Accessibility") }
            }
        } else {
            Text(
                "Whole phone = the border over every app (touches pass through). Android does not allow overlays on the lock screen and some secure apps.",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Text("Pulse strength: ${aStr.toInt()}")
        Slider(
            value = aStr,
            onValueChange = { v -> val r = Math.round(v); aStr = r.toFloat(); s.auraStrength = r; Meera.aura.settingsChanged() },
            valueRange = 1f..10f, steps = 8
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(aAll, { aAll = it; s.auraAllStates = it; Meera.aura.settingsChanged() }); Text("  Also show while listening / thinking (off = only while speaking)")
        }

        SectionTitle("Appearance & shortcuts")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("dark", "light", "system").forEach { t ->
                FilterChip(selected = theme == t, onClick = { theme = t; s.theme = t }, label = { Text(t) })
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(quick, { quick = it; s.quickAccess = it; if (it) QuickAccess.show(ctx) else QuickAccess.hide(ctx) })
            Text("  Quick-access notification")
        }
    }
}
